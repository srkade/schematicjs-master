
-- PostgreSQL schema for schematic backend (normalized)

-- Components are logical devices (e.g., ECU, sensor, actuator).
CREATE TABLE component (
  component_id        TEXT PRIMARY KEY,         -- stable engineering code (e.g., "ECT_SENSOR")
  name                TEXT,                     -- human-friendly
  manufacturer        TEXT,
  category            TEXT,
  created_at          TIMESTAMPTZ DEFAULT now()
);

-- Nodes unify connectors and splices so wires can point to a single table.
-- node_type = 'CONNECTOR' | 'SPLICE'
CREATE TABLE node (
  node_id             TEXT PRIMARY KEY,         -- e.g., "X101", "XS1"
  node_type           TEXT NOT NULL CHECK (node_type IN ('CONNECTOR','SPLICE')),
  component_id        TEXT NULL REFERENCES component(component_id) ON DELETE SET NULL,  -- null for splices
  created_at          TIMESTAMPTZ DEFAULT now()
);

-- Connector-specific properties (exists if node.node_type = 'CONNECTOR')
CREATE TABLE connector (
  node_id             TEXT PRIMARY KEY REFERENCES node(node_id) ON DELETE CASCADE,
  engineering_code    TEXT,                     -- "Engineering Connector Code"
  connector_code      TEXT,                     -- "Connector Code"
  part_number         TEXT,                     -- "Connector Part Number"
  gender              TEXT,
  connector_type      TEXT,
  manufacturer        TEXT
);

-- Cavity (pin) catalog for each connector
CREATE TABLE cavity (
  node_id             TEXT REFERENCES node(node_id) ON DELETE CASCADE,
  cavity              TEXT NOT NULL,            -- normalized cavity/pin (e.g., "1", "A1")
  label               TEXT,                     -- optional print label
  PRIMARY KEY (node_id, cavity)
);

-- Optional splice-specific properties if you need to store variants.
CREATE TABLE splice (
  node_id             TEXT PRIMARY KEY REFERENCES node(node_id) ON DELETE CASCADE
);

-- Circuits/nets
CREATE TABLE circuit (
  circuit_id          TEXT PRIMARY KEY,
  description         TEXT
);

-- Wires connect two nodes (connector or splice) and optional cavities
CREATE TABLE wire (
  wire_id             TEXT PRIMARY KEY,         -- can be natural from source or generated
  circuit_id          TEXT REFERENCES circuit(circuit_id),
  from_node_id        TEXT NOT NULL REFERENCES node(node_id) ON DELETE RESTRICT,
  from_cavity         TEXT,                      -- nullable for splices
  to_node_id          TEXT NOT NULL REFERENCES node(node_id) ON DELETE RESTRICT,
  to_cavity           TEXT,
  color               TEXT,
  size                TEXT,                      -- gauge
  length_mm           INTEGER,
  shield_id           TEXT,
  twist_id            TEXT,
  wire_type           TEXT,
  wire_option         TEXT,
  mark                TEXT
);

-- Indices for fast lookups
CREATE INDEX idx_node_component ON node(component_id);
CREATE INDEX idx_wire_from ON wire(from_node_id);
CREATE INDEX idx_wire_to   ON wire(to_node_id);
CREATE INDEX idx_wire_circuit ON wire(circuit_id);

CREATE OR REPLACE VIEW schematic_json AS
SELECT
  c.component_id,
  jsonb_build_object(
    'components', (
      SELECT jsonb_agg(
        jsonb_build_object(
          'id', c.component_id,
          'label', c.name
        )
      )
    ),
    'splices', (
      SELECT coalesce(jsonb_agg(DISTINCT jsonb_build_object('id', n2.node_id)), '[]'::jsonb)
      FROM wire w
      JOIN node n1 ON n1.node_id = w.from_node_id OR n1.node_id = w.to_node_id
      JOIN node n2 ON n2.node_id IN (w.from_node_id, w.to_node_id)
      WHERE n1.component_id = c.component_id AND n2.node_type = 'SPLICE'
    ),
    'wires', (
      SELECT coalesce(jsonb_agg(
        jsonb_build_object(
          'id', w.wire_id,
          'circuitId', w.circuit_id,
          'from', jsonb_build_object('connector', w.from_node_id, 'cavity', coalesce(w.from_cavity,'')),
          'to',   jsonb_build_object('connector', w.to_node_id,   'cavity', coalesce(w.to_cavity,'')),
          'color', w.color
        )
      ), '[]'::jsonb)
      FROM wire w
      JOIN node nc ON nc.node_id IN (w.from_node_id, w.to_node_id)
      WHERE nc.component_id = c.component_id
    )
  ) AS model
FROM component c
GROUP BY c.component_id;

-- Example: fetch model for one component_id
-- SELECT model FROM schematic_json WHERE component_id = 'ECT_SENSOR';

-- Vehicle & Configuration
CREATE TABLE IF NOT EXISTS vehicle_model (
  model_id TEXT PRIMARY KEY,
  name TEXT,
  manufacturer TEXT
);
CREATE TABLE IF NOT EXISTS vehicle_variant (
  variant_id TEXT PRIMARY KEY,
  model_id TEXT REFERENCES vehicle_model(model_id) ON DELETE CASCADE,
  name TEXT
);
CREATE TABLE IF NOT EXISTS schematic_configuration (
  config_id TEXT PRIMARY KEY,                -- use your own codes or UUIDs
  variant_id TEXT REFERENCES vehicle_variant(variant_id) ON DELETE CASCADE,
  name TEXT,
  status TEXT NOT NULL DEFAULT 'UNPUBLISHED',-- UNPUBLISHED | PUBLISHED
  published_at TIMESTAMPTZ
);

-- Systems / Harnesses / DTCs (live under a configuration)
CREATE TABLE IF NOT EXISTS system_def (
  system_id TEXT PRIMARY KEY,
  config_id TEXT REFERENCES schematic_configuration(config_id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT,
  formula TEXT,                               -- e.g. ICC=B4=B3
  UNIQUE (config_id, code)
);
CREATE TABLE IF NOT EXISTS harness_def (
  harness_id TEXT PRIMARY KEY,
  config_id TEXT REFERENCES schematic_configuration(config_id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT,
  formula TEXT,                               -- e.g. ICC=B4=B3
  UNIQUE (config_id, code)
);
CREATE TABLE IF NOT EXISTS dtc_def (
  dtc_id TEXT PRIMARY KEY,
  config_id TEXT REFERENCES schematic_configuration(config_id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  formula TEXT,                               -- e.g. ICC=B4=B3
  UNIQUE (config_id, code)
);

-- Optional, normalized membership (can be populated by your loader from formulas)
CREATE TABLE IF NOT EXISTS system_component (
  system_id TEXT REFERENCES system_def(system_id) ON DELETE CASCADE,
  component_id TEXT REFERENCES component(component_id) ON DELETE CASCADE,
  PRIMARY KEY (system_id, component_id)
);
CREATE TABLE IF NOT EXISTS harness_component (
  harness_id TEXT REFERENCES harness_def(harness_id) ON DELETE CASCADE,
  component_id TEXT REFERENCES component(component_id) ON DELETE CASCADE,
  PRIMARY KEY (harness_id, component_id)
);

-- Useful indexes
CREATE INDEX IF NOT EXISTS idx_variant_model ON vehicle_variant(model_id);
CREATE INDEX IF NOT EXISTS idx_config_variant ON schematic_configuration(variant_id);
CREATE INDEX IF NOT EXISTS idx_sys_config ON system_def(config_id);
CREATE INDEX IF NOT EXISTS idx_har_config ON harness_def(config_id);
CREATE INDEX IF NOT EXISTS idx_dtc_config ON dtc_def(config_id);
