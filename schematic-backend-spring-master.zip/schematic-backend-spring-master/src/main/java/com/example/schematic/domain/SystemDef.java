package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "system_def", uniqueConstraints = @UniqueConstraint(columnNames = {"config_id", "code"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemDef {
    @Id
    @Column(name = "system_id")
    private String systemId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "config_id")
    private SchematicConfiguration config;
    @Column(nullable = false)
    private String code;
    private String name;
    private String formula; // e.g. ICC=B4=B3..
}
