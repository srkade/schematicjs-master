package com.example.schematic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchematicApplication {
    public static void main(String[] args) {
        SpringApplication.run(SchematicApplication.class, args);
    }
}
