package com.example.schematic.domain;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "system_component")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemComponent {
    @EmbeddedId
    private SystemComponentId id;
}
