package com.example.schematic.repo;

import com.example.schematic.domain.VehicleModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleModelRepository extends JpaRepository<VehicleModel, String> {
}
