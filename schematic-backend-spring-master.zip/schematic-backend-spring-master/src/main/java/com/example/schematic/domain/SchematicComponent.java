package com.example.schematic.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "component")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class SchematicComponent {
    @Id
    @Column(name = "component_id")
    private String componentId;
    private String name;
    private String manufacturer;
    private String category;
}
