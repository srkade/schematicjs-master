package com.example.schematic.domain;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "harness_component")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HarnessComponent {
    @EmbeddedId
    private HarnessComponentId id;
}
