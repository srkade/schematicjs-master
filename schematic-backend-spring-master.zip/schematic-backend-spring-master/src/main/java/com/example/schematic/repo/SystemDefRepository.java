package com.example.schematic.repo;

import com.example.schematic.domain.SystemDef;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SystemDefRepository extends JpaRepository<SystemDef, String> {
    List<SystemDef> findByConfig_ConfigId(String configId);

    Optional<SystemDef> findByConfig_ConfigIdAndCode(String configId, String code);
}
