package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "dtc_def", uniqueConstraints = @UniqueConstraint(columnNames = {"config_id", "code"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DtcDef {
    @Id
    @Column(name = "dtc_id")
    private String dtcId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "config_id")
    private SchematicConfiguration config;
    @Column(nullable = false)
    private String code;
    private String formula; // e.g. ICC=B4=B3..
}
