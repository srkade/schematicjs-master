package com.example.schematic.importer;

import com.example.schematic.config.ImportProperties;
import com.example.schematic.domain.*;
import com.example.schematic.repo.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.boot.CommandLineRunner;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Component
public class CsvImportRunner implements CommandLineRunner {

    private final ImportProperties props;
    private final ComponentRepository componentRepo;
    private final NodeRepository nodeRepo;
    private final ConnectorRepository connectorRepo;
    private final CircuitRepository circuitRepo;
    private final WireRepository wireRepo;
    private final CavityRepository cavityRepo;

    public CsvImportRunner(ImportProperties props,
                           ComponentRepository componentRepo,
                           NodeRepository nodeRepo,
                           ConnectorRepository connectorRepo,
                           CircuitRepository circuitRepo,
                           WireRepository wireRepo,
                           CavityRepository cavityRepo) {
        this.props = props;
        this.componentRepo = componentRepo;
        this.nodeRepo = nodeRepo;
        this.connectorRepo = connectorRepo;
        this.circuitRepo = circuitRepo;
        this.wireRepo = wireRepo;
        this.cavityRepo = cavityRepo;
    }

    @Override
    public void run(String... args) throws Exception {
        if (!props.isEnabled()) return;
        if (props.getServiceConnectorCsv() != null && !props.getServiceConnectorCsv().isBlank()) {
            importServiceConnector(new File(props.getServiceConnectorCsv()));
        }
        if (props.getWireListCsv() != null && !props.getWireListCsv().isBlank()) {
            importWireList(new File(props.getWireListCsv()));
        }
    }

    private static String n(String s) {
        return s == null ? "" : s.trim();
    }

    private static String up(String s) {
        return n(s).toUpperCase(Locale.ROOT);
    }

    private static String normCav(String s) {
        return up(s).replaceAll("\\s+", "");
    }

    private static boolean isSpliceId(String id) {
        if (id == null) return false;
        String s = id.trim().toUpperCase(Locale.ROOT);
        // Common harness conventions:
        //  XS…  = splice (e.g., XS3, XS_623, XSPL…)
        //  XSP… = splice block
        //  SPLICE  or “…SPLICE…” marks
        return s.startsWith("XS")               // catches XS3, XS_623, XSPLxxx
                || s.startsWith("XSP")
                || s.contains("SPLICE");
    }


    @Transactional
    protected void importServiceConnector(File file) throws Exception {
        if (!file.exists()) return;

        try (Reader reader = new FileReader(file, StandardCharsets.UTF_8);
             CSVParser parser = CSVFormat.DEFAULT
                     .withFirstRecordAsHeader()
                     .withIgnoreEmptyLines()
                     .parse(reader)) {

            Map<String, Integer> hdr = parser.getHeaderMap();

            for (CSVRecord r : parser) {
                // ---------- component ----------
                String compCode = firstNonBlank(r, hdr,
                        "Component Code", "ENGINEERING COMPONENT CODE", "Engineering Component Code");
                String compName = firstNonBlank(r, hdr, "Engineering Component Name", "Component Name");
                String compId = n(compCode).isBlank()
                        ? up(compName).replaceAll("[^A-Z0-9]+", "_")
                        : up(compCode);
                if (n(compId).isBlank()) continue;

                SchematicComponent comp = componentRepo.findById(compId)
                        .orElseGet(() -> SchematicComponent.builder().componentId(compId).build());
                if (comp.getName() == null || comp.getName().isBlank()) comp.setName(n(compName));
                comp.setManufacturer(firstNonBlank(r, hdr, "Engineering Manufacturer", "Manufacturer"));
                comp.setCategory(firstNonBlank(r, hdr, "Component Category"));
                componentRepo.save(comp);

                // ---------- connector / splice id ----------
                String rawNodeId = firstNonBlank(r, hdr, "Engineering Connector Code", "Connector Code");
                String nodeId = n(rawNodeId);            // TRIM!
                if (nodeId.isBlank()) {
                    System.err.println("Skip row: blank connector code. Row=" + r.getRecordNumber());
                    continue;
                }

                // Splices DO NOT go into connector table
                if (isSpliceId(nodeId)) {
                    Node sp = nodeRepo.findById(nodeId).orElseGet(() -> Node.builder().nodeId(nodeId).build());
                    sp.setNodeType(NodeType.SPLICE);
                    sp.setComponent(null);
                    nodeRepo.save(sp);
                    System.out.println("Skipping splice in ServiceConnector: " + nodeId);
                    continue;
                }

                // ---------- ensure CONNECTOR node first ----------
                Node node = nodeRepo.findById(nodeId).orElseGet(() -> Node.builder().nodeId(nodeId).build());
                node.setNodeType(NodeType.CONNECTOR);
                node.setComponent(comp);
                node = nodeRepo.save(node);   // managed & has id

                // ---------- upsert Connector with @MapsId ----------
                // DO NOT create/persist a Connector unless id is non-blank and node is CONNECTOR
                if (node.getNodeType() != NodeType.CONNECTOR) {
                    System.err.println("Skip connector: node is not CONNECTOR: " + nodeId);
                    continue;
                }

                // upsert Connector — just set the id and attributes
                Connector cx = connectorRepo.findById(nodeId).orElseGet(Connector::new);
                cx.setNodeId(nodeId);  // <-- this is the PK and also the FK
                cx.setEngineeringCode(firstNonBlank(r, hdr, "Engineering Connector Code"));
                cx.setConnectorCode(firstNonBlank(r, hdr, "Connector Code"));
                cx.setPartNumber(firstNonBlank(r, hdr, "Connector Part Number", "Primary PN"));
                cx.setGender(firstNonBlank(r, hdr, "Gender"));
                cx.setConnectorType(firstNonBlank(r, hdr, "Connector Type"));
                cx.setManufacturer(firstNonBlank(r, hdr, "Manufacturer", "Engineering Manufacturer"));

                connectorRepo.saveAndFlush(cx);
            }
        } catch (DataAccessException dae) {
            // bubble up with context if you want
            throw dae;
        }
    }


    @Transactional
    protected void importWireList(File file) throws Exception {
        if (!file.exists()) return;
        try (Reader reader = new FileReader(file, StandardCharsets.UTF_8);
             CSVParser parser = CSVFormat.DEFAULT
                     .withFirstRecordAsHeader()
                     .withIgnoreEmptyLines()
                     .parse(reader)) {
            Map<String, Integer> hdr = parser.getHeaderMap();
            int seq = 0;

            // cache for cavities per connector
            Map<String, Set<String>> cavities = new HashMap<>();

            for (CSVRecord r : parser) {
                String circuitId = firstNonBlank(r, hdr, "CIRCUITNUMBER", "CIRCUIT NUMBER", "CIRCUIT", "WIRE_ID");
                if (n(circuitId).isBlank()) circuitId = "CIR-" + (++seq);
                String finalCircuitId = circuitId;
                Circuit circuit = circuitRepo.findById(circuitId).orElseGet(() -> Circuit.builder().circuitId(finalCircuitId).build());
                if (circuit.getDescription() == null) circuit.setDescription(null);
                circuitRepo.save(circuit);

                String fromConn = firstNonBlank(r, hdr, "FROM-CONNNUMBER", "FROM-CONN NUMBER", "FROM-CONNECTOR", "FROM-CONNNUMBER ");
                String toConn = firstNonBlank(r, hdr, "TO-CONNNUMBER", "TO-CONN NUMBER", "TO-CONNECTOR", "TO-CONNNUMBER ");
                String fromCav = firstNonBlank(r, hdr, "FROM-CAVITY", "FROM CAVITY");
                fromCav = normCav(fromCav);
                String toCav = firstNonBlank(r, hdr, "TO-CAVITY", "TO CAVITY");
                toCav = normCav(toCav);

                if (n(fromConn).isBlank() || n(toConn).isBlank()) continue;

                // ensure nodes exist (CONNECTOR default unless splice pattern)
                ensureNode(fromConn);
                ensureNode(toConn);

                // collect cavities
                if (!fromCav.isBlank()) cavities.computeIfAbsent(fromConn, k -> new HashSet<>()).add(fromCav);
                if (!toCav.isBlank()) cavities.computeIfAbsent(toConn, k -> new HashSet<>()).add(toCav);

                String wireId = firstNonBlank(r, hdr, "WIRE_ID", "WIREID", "ID");
                if (n(wireId).isBlank()) wireId = "W" + (++seq);

                Wire w = new Wire();
                w.setWireId(wireId);
                w.setCircuit(circuit);
                w.setFromNodeId(fromConn);
                w.setFromCavity(fromCav.isBlank() ? null : fromCav);
                w.setToNodeId(toConn);
                w.setToCavity(toCav.isBlank() ? null : toCav);
                w.setColor(firstNonBlank(r, hdr, "WIRECOLOR", "WIRE COLOR", "COLOR"));
                w.setSize(firstNonBlank(r, hdr, "WIRESIZE", "WIRE SIZE"));
                String length = firstNonBlank(r, hdr, "WIRELENGTH", "WIRE LENGTH");
                try {
                    if (!n(length).isBlank()) w.setLengthMm((int) Math.round(Double.parseDouble(length)));
                } catch (Exception ignore) {
                }
                w.setShieldId(firstNonBlank(r, hdr, "SHIELD ID", "SHIELDID"));
                w.setTwistId(firstNonBlank(r, hdr, "TWIST ID", "TWISTID"));
                w.setWireType(firstNonBlank(r, hdr, "WIRE TYPE"));
                w.setWireOption(firstNonBlank(r, hdr, "WIREOPTION", "WIRE OPTION"));
                w.setMark(firstNonBlank(r, hdr, "MARK"));

                wireRepo.save(w);
            }

            // upsert cavities
            for (var e : cavities.entrySet()) {
                String nodeId = e.getKey();
                for (String cav : e.getValue()) {
                    CavityId id = new CavityId(nodeId, cav);
                    if (!cavityRepo.existsById(id)) {
                        Cavity cv = new Cavity();
                        cv.setId(id);
                        cv.setLabel(cav);
                        cavityRepo.save(cv);
                    }
                }
            }
        }
    }

    private void ensureNode(String nodeId) {
        nodeRepo.findById(nodeId).orElseGet(() -> {
            Node n = new Node();
            n.setNodeId(nodeId);
            n.setNodeType(isSpliceId(nodeId) ? NodeType.SPLICE : NodeType.CONNECTOR);
            n.setComponent(null); // unknown until ServiceConnector import maps it
            return nodeRepo.save(n);
        });
    }

    private static String firstNonBlank(CSVRecord r, Map<String, Integer> hdr, String... names) {
        for (String n : names) {
            if (hdr.containsKey(n)) {
                String v = r.get(n);
                if (v != null && !v.trim().isBlank()) return v.trim();
            }
        }
        // also try case-insensitive
        for (String n : names) {
            for (String h : hdr.keySet()) {
                if (h.equalsIgnoreCase(n)) {
                    String v = r.get(h);
                    if (v != null && !v.trim().isBlank()) return v.trim();
                }
            }
        }
        return "";
    }
}
