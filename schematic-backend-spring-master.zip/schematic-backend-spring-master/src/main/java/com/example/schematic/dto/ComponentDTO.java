package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComponentDTO {
    private String id;
    private String label;
    private String category;
}