package com.example.schematic.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchematicModelDTO {
    private List<ComponentDTO> components;
    private List<SpliceDTO> splices;
    private List<WireDTO> wires;
}