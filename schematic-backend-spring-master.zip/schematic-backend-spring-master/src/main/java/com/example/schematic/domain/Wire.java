package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "wire")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Wire {
    @Id
    @Column(name = "wire_id")
    private String wireId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "circuit_id")
    private Circuit circuit;

    @Column(name = "from_node_id", nullable = false)
    private String fromNodeId;
    @Column(name = "from_cavity")
    private String fromCavity;

    @Column(name = "to_node_id", nullable = false)
    private String toNodeId;
    @Column(name = "to_cavity")
    private String toCavity;

    private String color;
    private String size;
    @Column(name = "length_mm")
    private Integer lengthMm;

    @Column(name = "shield_id")
    private String shieldId;
    @Column(name = "twist_id")
    private String twistId;
    @Column(name = "wire_type")
    private String wireType;
    @Column(name = "wire_option")
    private String wireOption;
    private String mark;
}
