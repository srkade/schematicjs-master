package com.example.schematic.repo;

import com.example.schematic.domain.VehicleVariant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VehicleVariantRepository extends JpaRepository<VehicleVariant, String> {
    List<VehicleVariant> findByModel_ModelId(String modelId);
}
