package com.example.schematic.service;

import com.example.schematic.domain.Node;
import com.example.schematic.domain.NodeType;
import com.example.schematic.domain.Wire;
import com.example.schematic.dto.*;
import com.example.schematic.repo.ComponentRepository;
import com.example.schematic.repo.NodeRepository;
import com.example.schematic.repo.WireRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SchematicService {
    private final ComponentRepository componentRepo;
    private final NodeRepository nodeRepo;
    private final WireRepository wireRepo;

    public SchematicService(ComponentRepository componentRepo, NodeRepository nodeRepo, WireRepository wireRepo) {
        this.componentRepo = componentRepo;
        this.nodeRepo = nodeRepo;
        this.wireRepo = wireRepo;
    }

    @Transactional(readOnly = true)
    public Optional<SchematicModelDTO> getModelForComponent(String componentId) {
        var componentOpt = componentRepo.findById(componentId);
        if (componentOpt.isEmpty()) return Optional.empty();
        var component = componentOpt.get();

        // All connectors belonging to this component
        var connectors = nodeRepo.findByComponent_ComponentIdAndNodeType(componentId, NodeType.CONNECTOR);
        var connectorIds = connectors.stream().map(Node::getNodeId).collect(Collectors.toSet());
        if (connectorIds.isEmpty()) {
            return Optional.of(
                    SchematicModelDTO.builder()
                            .components(List.of(ComponentDTO.builder().id(component.getComponentId()).label(component.getName()).build()))
                            .splices(Collections.emptyList())
                            .wires(Collections.emptyList())
                            .build()
            );
        }

        // All wires touching any of these connectors
        var wires = wireRepo.findTouchingNodes(connectorIds);

        // Collect splices present in those wires
        Set<String> spliceIds = new HashSet<>();
        for (var w : wires) {
            if (isSpliceId(w.getFromNodeId())) spliceIds.add(w.getFromNodeId());
            if (isSpliceId(w.getToNodeId())) spliceIds.add(w.getToNodeId());
        }

        var spliceDtos = spliceIds.stream().sorted().map(id -> new SpliceDTO(id)).toList();
        var wireDtos = wires.stream().map(w -> WireDTO.builder()
                .id(w.getWireId())
                .circuitId(w.getCircuit() != null ? w.getCircuit().getCircuitId() : null)
                .from(new WireEndDTO(w.getFromNodeId(), n(w.getFromCavity())))
                .to(new WireEndDTO(w.getToNodeId(), n(w.getToCavity())))
                .color(w.getColor())
                .build()
        ).toList();

        var compDto = ComponentDTO.builder().id(component.getComponentId()).label(component.getName()).category(component.getCategory()).build();
        return Optional.of(SchematicModelDTO.builder()
                .components(List.of(compDto))
                .splices(spliceDtos)
                .wires(wireDtos)
                .build());
    }

    private static String n(String s) {
        return s == null ? "" : s;
    }

    // same basic rule as FE; refine later with DB flag
    private static boolean isSpliceId(String id) {
        if (id == null) return false;
        String s = id.toUpperCase(Locale.ROOT);
        return s.matches("^XS(P|PL|P_).*") || s.startsWith("XSP") || s.contains("SPLICE");
    }


    @Transactional(readOnly = true)
    public Optional<MultiSchematicDTO> getModelForComponents(Collection<String> componentIds) {
        return getModelForComponents(componentIds, 0); // immediate only
    }


    @Transactional(readOnly = true)
    public Optional<MultiSchematicDTO> getModelForComponents(Collection<String> componentIds, int hops) {
        if (componentIds == null || componentIds.isEmpty()) return Optional.empty();
        Set<String> req = new LinkedHashSet<>();
        for (String id : componentIds) if (id != null && !id.trim().isBlank()) req.add(id.trim());
        if (req.isEmpty()) return Optional.empty();

        // 1) Connectors that belong to requested components
        var requestedConnectors = nodeRepo.findByComponentIdsAndType(req, NodeType.CONNECTOR);
        var baseConnectorIds = requestedConnectors.stream().map(Node::getNodeId).collect(Collectors.toSet());
        if (baseConnectorIds.isEmpty()) {
            List<ComponentDTO> comps = componentRepo.findAllById(req).stream()
                    .map(c -> ComponentDTO.builder().id(c.getComponentId()).label(c.getName()).category(c.getCategory()).build())
                    .toList();
            return Optional.of(MultiSchematicDTO.builder()
                    .requested(new ArrayList<>(req))
                    .components(comps).connectors(List.of()).splices(List.of()).wires(List.of()).build());
        }

        // 2) Wires that touch ANY requested connector (immediate)
        var wires = new ArrayList<Wire>(wireRepo.findTouchingNodes(baseConnectorIds));

        // 3) Optional: expand across splices ONE hop if requested
        if (hops >= 1) {
            Set<String> firstSplices = new LinkedHashSet<>();
            for (var w : wires) {
                if (isSpliceId(w.getFromNodeId())) firstSplices.add(w.getFromNodeId());
                if (isSpliceId(w.getToNodeId())) firstSplices.add(w.getToNodeId());
            }
            if (!firstSplices.isEmpty()) {
                var across = wireRepo.findTouchingNodes(firstSplices);
                for (var w2 : across) if (!wires.contains(w2)) wires.add(w2);
            }
        }

        // 4) Involved node ids and used pins (strictly endpoints of selected wires)
        Set<String> involvedNodeIds = new LinkedHashSet<>();
        Map<String, Set<String>> usedPins = new HashMap<>();
        for (var w : wires) {
            if (w.getFromNodeId() != null) {
                involvedNodeIds.add(w.getFromNodeId());
                if (w.getFromCavity() != null && !w.getFromCavity().isBlank())
                    usedPins.computeIfAbsent(w.getFromNodeId(), k -> new LinkedHashSet<>()).add(w.getFromCavity());
            }
            if (w.getToNodeId() != null) {
                involvedNodeIds.add(w.getToNodeId());
                if (w.getToCavity() != null && !w.getToCavity().isBlank())
                    usedPins.computeIfAbsent(w.getToNodeId(), k -> new LinkedHashSet<>()).add(w.getToCavity());
            }
        }

        // 5) Resolve nodes and partition
        var allNodes = nodeRepo.findAllByIds(involvedNodeIds);
        Map<String, Node> nodeById = new HashMap<>();
        for (var n : allNodes) nodeById.put(n.getNodeId(), n);

        Set<String> spliceIds = new LinkedHashSet<>();
        Set<String> connectorIds = new LinkedHashSet<>();
        Set<String> ownerComponentIds = new LinkedHashSet<>(req);

        for (String nid : involvedNodeIds) {
            var n = nodeById.get(nid);
            if (n == null) continue;
            if (n.getNodeType() == NodeType.SPLICE) {
                spliceIds.add(nid);
            } else if (n.getNodeType() == NodeType.CONNECTOR) {
                connectorIds.add(nid);
                if (n.getComponent() != null && n.getComponent().getComponentId() != null)
                    ownerComponentIds.add(n.getComponent().getComponentId());
            }
        }

        // 6) Connectors (only endpoints) with used pins only
        List<ConnectorPinsDTO> connectorDtos = new ArrayList<>();
        for (String cid : connectorIds) {
            var node = nodeById.get(cid);
            String compId = (node != null && node.getComponent() != null) ? node.getComponent().getComponentId() : null;
            List<String> pins = new ArrayList<>(usedPins.getOrDefault(cid, Set.of()));
            Collections.sort(pins);
            connectorDtos.add(ConnectorPinsDTO.builder().id(cid).componentId(compId).usedPins(pins).build());
        }

        // 7) Splices (only those that are endpoints of selected wires)
        var spliceDtos = spliceIds.stream().sorted().map(SpliceDTO::new).toList();

        // 8) Components (requested + owners of those endpoint connectors)
        var compEntities = componentRepo.findAllById(ownerComponentIds);
        Map<String, String> compName = new HashMap<>();
        for (var c : compEntities) compName.put(c.getComponentId(), c.getName());
        Map<String, String> compCategory = new HashMap<>();
        for (var c : compEntities) compCategory.put(c.getComponentId(), c.getCategory());

        List<ComponentDTO> compDtos = new ArrayList<>();
        for (String id : ownerComponentIds)
            compDtos.add(ComponentDTO.builder().id(id).label(compName.get(id)).category(compCategory.get(id)).build());

        // 9) Wires (as-is)
        var wireDtos = wires.stream().map(w -> WireDTO.builder()
                .id(w.getWireId())
                .circuitId(w.getCircuit() != null ? w.getCircuit().getCircuitId() : null)
                .from(new WireEndDTO(w.getFromNodeId(), n(w.getFromCavity())))
                .to(new WireEndDTO(w.getToNodeId(), n(w.getToCavity())))
                .color(w.getColor())
                .build()).toList();

        return Optional.of(MultiSchematicDTO.builder()
                .requested(new ArrayList<>(req))
                .components(compDtos)
                .connectors(connectorDtos)
                .splices(spliceDtos)
                .wires(wireDtos)
                .build());
    }


}
