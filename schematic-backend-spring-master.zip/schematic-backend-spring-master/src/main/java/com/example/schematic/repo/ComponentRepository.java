package com.example.schematic.repo;

import com.example.schematic.domain.SchematicComponent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComponentRepository extends JpaRepository<SchematicComponent, String> {
}