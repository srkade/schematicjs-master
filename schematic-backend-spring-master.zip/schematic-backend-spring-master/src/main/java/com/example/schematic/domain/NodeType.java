package com.example.schematic.domain;

public enum NodeType {CONNECTOR, SPLICE}
