package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "splice")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Splice {
    @Id
    @Column(name = "node_id")
    private String nodeId;

    @OneToOne
    @MapsId
    @JoinColumn(name = "node_id")
    private Node node;
}
