package com.example.schematic.repo;

import com.example.schematic.domain.SystemComponent;
import com.example.schematic.domain.SystemComponentId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SystemComponentRepository extends JpaRepository<SystemComponent, SystemComponentId> {
    List<SystemComponent> findById_SystemId(String systemId);
}
