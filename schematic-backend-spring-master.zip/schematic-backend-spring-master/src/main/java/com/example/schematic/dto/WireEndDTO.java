package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WireEndDTO {
    private String connector;
    private String cavity;
}