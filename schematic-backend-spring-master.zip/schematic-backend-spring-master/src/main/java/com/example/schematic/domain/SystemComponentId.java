package com.example.schematic.domain;

import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class SystemComponentId implements Serializable {
    private String systemId;
    private String componentId;
}
