package com.example.schematic.repo;

import com.example.schematic.domain.Node;
import com.example.schematic.domain.NodeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface NodeRepository extends JpaRepository<Node, String> {
    List<Node> findByComponent_ComponentIdAndNodeType(String componentId, NodeType nodeType);

    @Query("select n from Node n where n.nodeId in :ids")
    List<Node> findAllByIds(@Param("ids") Collection<String> ids);

    @Query("select n from Node n where n.component.componentId in :componentIds and n.nodeType = :type")
    List<Node> findByComponentIdsAndType(@Param("componentIds") Collection<String> componentIds,
                                         @Param("type") NodeType type);

}