package com.example.schematic.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "import")
public class ImportProperties {
    /**
     * Enable CSV import on startup
     */
    private boolean enabled = false;

    /**
     * Path to ServiceConnector.csv
     */
    private String serviceConnectorCsv;

    /**
     * Path to WireList.csv
     */
    private String wireListCsv;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getServiceConnectorCsv() {
        return serviceConnectorCsv;
    }

    public void setServiceConnectorCsv(String serviceConnectorCsv) {
        this.serviceConnectorCsv = serviceConnectorCsv;
    }

    public String getWireListCsv() {
        return wireListCsv;
    }

    public void setWireListCsv(String wireListCsv) {
        this.wireListCsv = wireListCsv;
    }
}
