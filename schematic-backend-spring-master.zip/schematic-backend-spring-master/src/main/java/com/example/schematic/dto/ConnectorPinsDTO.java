package com.example.schematic.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConnectorPinsDTO {
    private String id;                 // connector node_id
    private String componentId;        // owner component (may be null if unknown)
    private List<String> usedPins;     // ONLY cavities referenced by returned wires
}
