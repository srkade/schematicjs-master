package com.example.schematic.repo;

import com.example.schematic.domain.HarnessDef;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface HarnessDefRepository extends JpaRepository<HarnessDef, String> {
    List<HarnessDef> findByConfig_ConfigId(String configId);

    Optional<HarnessDef> findByConfig_ConfigIdAndCode(String configId, String code);
}
