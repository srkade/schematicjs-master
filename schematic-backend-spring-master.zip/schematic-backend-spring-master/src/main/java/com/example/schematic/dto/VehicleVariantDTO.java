package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleVariantDTO {
    private String id;
    private String modelId;
    private String name;
}
