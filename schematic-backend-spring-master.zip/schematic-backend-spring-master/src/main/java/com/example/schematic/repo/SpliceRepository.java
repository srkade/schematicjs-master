package com.example.schematic.repo;

import com.example.schematic.domain.Splice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpliceRepository extends JpaRepository<Splice, String> {
}