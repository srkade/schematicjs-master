package com.example.schematic.repo;

import com.example.schematic.domain.Circuit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CircuitRepository extends JpaRepository<Circuit, String> {
}