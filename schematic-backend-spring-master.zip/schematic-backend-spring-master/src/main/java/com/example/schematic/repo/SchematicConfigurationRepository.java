package com.example.schematic.repo;

import com.example.schematic.domain.SchematicConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SchematicConfigurationRepository extends JpaRepository<SchematicConfiguration, String> {
    List<SchematicConfiguration> findByVariant_VariantId(String variantId);
}
