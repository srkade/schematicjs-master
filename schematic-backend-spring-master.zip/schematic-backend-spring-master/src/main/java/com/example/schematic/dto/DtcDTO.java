package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DtcDTO {
    private String id;
    private String configId;
    private String code;
    private String formula;
}
