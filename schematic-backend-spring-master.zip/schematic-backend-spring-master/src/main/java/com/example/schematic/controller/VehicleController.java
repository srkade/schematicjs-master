package com.example.schematic.controller;

import com.example.schematic.domain.PublishStatus;
import com.example.schematic.domain.SchematicConfiguration;
import com.example.schematic.domain.VehicleModel;
import com.example.schematic.domain.VehicleVariant;
import com.example.schematic.dto.SchematicConfigurationDTO;
import com.example.schematic.dto.VehicleModelDTO;
import com.example.schematic.dto.VehicleVariantDTO;
import com.example.schematic.repo.SchematicConfigurationRepository;
import com.example.schematic.repo.VehicleModelRepository;
import com.example.schematic.repo.VehicleVariantRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.OffsetDateTime;

@RestController
@RequestMapping("/api")
public class VehicleController {
    private final VehicleModelRepository modelRepo;
    private final VehicleVariantRepository variantRepo;
    private final SchematicConfigurationRepository configRepo;

    public VehicleController(VehicleModelRepository m, VehicleVariantRepository v, SchematicConfigurationRepository c) {
        this.modelRepo = m;
        this.variantRepo = v;
        this.configRepo = c;
    }

    // Models
    @GetMapping("/models")
    public java.util.List<VehicleModelDTO> listModels() {
        return modelRepo.findAll().stream()
                .map(m -> VehicleModelDTO.builder().id(m.getModelId()).name(m.getName()).manufacturer(m.getManufacturer()).build())
                .toList();
    }

    @PostMapping("/models")
    public ResponseEntity<?> upsertModel(@RequestBody VehicleModelDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank()) return ResponseEntity.badRequest().body("model id required");
        VehicleModel m = modelRepo.findById(dto.getId()).orElseGet(() -> VehicleModel.builder().modelId(dto.getId()).build());
        m.setName(dto.getName());
        m.setManufacturer(dto.getManufacturer());
        modelRepo.save(m);
        return ResponseEntity.ok().build();
    }

    // Variants
    @GetMapping("/models/{modelId}/variants")
    public java.util.List<VehicleVariantDTO> listVariants(@PathVariable String modelId) {
        return variantRepo.findByModel_ModelId(modelId).stream()
                .map(v -> VehicleVariantDTO.builder().id(v.getVariantId()).modelId(modelId).name(v.getName()).build())
                .toList();
    }

    @PostMapping("/variants")
    public ResponseEntity<?> upsertVariant(@RequestBody VehicleVariantDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank() || dto.getModelId() == null || dto.getModelId().isBlank())
            return ResponseEntity.badRequest().body("variant id and modelId required");
        VehicleModel model = modelRepo.findById(dto.getModelId()).orElse(null);
        if (model == null) return ResponseEntity.badRequest().body("model not found");
        VehicleVariant v = variantRepo.findById(dto.getId()).orElseGet(() -> VehicleVariant.builder().variantId(dto.getId()).build());
        v.setName(dto.getName());
        v.setModel(model);
        variantRepo.save(v);
        return ResponseEntity.ok().build();
    }

    // Configs
    @GetMapping("/variants/{variantId}/configs")
    public java.util.List<SchematicConfigurationDTO> listConfigs(@PathVariable String variantId) {
        return configRepo.findByVariant_VariantId(variantId).stream()
                .map(c -> SchematicConfigurationDTO.builder()
                        .id(c.getConfigId()).variantId(variantId).name(c.getName())
                        .status(c.getStatus()).publishedAt(c.getPublishedAt() == null ? null : c.getPublishedAt().toString())
                        .build())
                .toList();
    }

    @PostMapping("/configs")
    public ResponseEntity<?> upsertConfig(@RequestBody SchematicConfigurationDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank() || dto.getVariantId() == null || dto.getVariantId().isBlank())
            return ResponseEntity.badRequest().body("config id and variantId required");
        VehicleVariant var = variantRepo.findById(dto.getVariantId()).orElse(null);
        if (var == null) return ResponseEntity.badRequest().body("variant not found");
        SchematicConfiguration c = configRepo.findById(dto.getId()).orElseGet(() -> SchematicConfiguration.builder().configId(dto.getId()).build());
        c.setVariant(var);
        c.setName(dto.getName());
        c.setStatus(dto.getStatus() == null ? PublishStatus.UNPUBLISHED : dto.getStatus());
        configRepo.save(c);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/configs/{configId}/publish")
    public ResponseEntity<?> publish(@PathVariable String configId) {
        var c = configRepo.findById(configId).orElse(null);
        if (c == null) return ResponseEntity.notFound().build();
        c.setStatus(PublishStatus.PUBLISHED);
        c.setPublishedAt(OffsetDateTime.now());
        configRepo.save(c);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/configs/{configId}/unpublish")
    public ResponseEntity<?> unpublish(@PathVariable String configId) {
        var c = configRepo.findById(configId).orElse(null);
        if (c == null) return ResponseEntity.notFound().build();
        c.setStatus(PublishStatus.UNPUBLISHED);
        c.setPublishedAt(null);
        configRepo.save(c);
        return ResponseEntity.ok().build();
    }
}
