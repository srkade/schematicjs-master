package com.example.schematic.repo;

import com.example.schematic.domain.HarnessComponent;
import com.example.schematic.domain.HarnessComponentId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HarnessComponentRepository extends JpaRepository<HarnessComponent, HarnessComponentId> {
    List<HarnessComponent> findById_HarnessId(String harnessId);
}
