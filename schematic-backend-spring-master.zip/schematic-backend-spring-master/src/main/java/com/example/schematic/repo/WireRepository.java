package com.example.schematic.repo;

import com.example.schematic.domain.Wire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface WireRepository extends JpaRepository<Wire, String> {
    @Query("select w from Wire w where w.fromNodeId in :ids or w.toNodeId in :ids")
    List<Wire> findTouchingNodes(@Param("ids") Collection<String> nodeIds);
}