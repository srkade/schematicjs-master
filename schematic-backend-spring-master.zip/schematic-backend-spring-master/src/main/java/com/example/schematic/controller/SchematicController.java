package com.example.schematic.controller;

import com.example.schematic.service.SchematicService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class SchematicController {
    private final SchematicService service;

    public SchematicController(SchematicService service) {
        this.service = service;
    }

    @GetMapping("/schematics/{componentId}")
    public ResponseEntity<?> getModel(@PathVariable("componentId") String componentId) {
        return service.getModelForComponent(componentId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Examples:
    //   /api/schematics?components=ICC=B4=X3        (immediate only)
    //   /api/schematics?components=ICC=B4=X3&hops=1 (across one splice)
    //   /api/schematics?componentId=ICC&componentId=B4&componentId=X3
    @GetMapping("/schematics")
    public ResponseEntity<?> getMulti(
            @RequestParam(value = "components", required = false) String components,
            @RequestParam(value = "componentId", required = false) List<String> componentIds,
            @RequestParam(value = "hops", required = false, defaultValue = "0") int hops) {

        List<String> ids = new ArrayList<>();
        if (components != null && !components.isBlank()) ids.addAll(parseComponents(components));
        if (componentIds != null) {
            for (String s : componentIds) if (s != null && !s.trim().isBlank()) ids.add(s.trim());
        }
        if (ids.isEmpty()) {
            return ResponseEntity.badRequest().body("Provide components=ICC=B4=X3 or componentId=... (repeated).");
        }

        return service.getModelForComponents(ids, hops)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    private static List<String> parseComponents(String raw) {
        return Arrays.stream(raw.split("[=,;\\s]+"))
                .map(String::trim).filter(s -> !s.isBlank()).toList();
    }
}
