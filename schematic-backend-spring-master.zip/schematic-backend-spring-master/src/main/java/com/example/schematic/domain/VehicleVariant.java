package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "vehicle_variant")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleVariant {
    @Id
    @Column(name = "variant_id")
    private String variantId;
    private String name;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "model_id")
    private VehicleModel model;
}
