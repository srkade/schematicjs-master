package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemHarnessDTO {
    private String id;
    private String configId;
    private String code;
    private String name;
    private String formula;
}
