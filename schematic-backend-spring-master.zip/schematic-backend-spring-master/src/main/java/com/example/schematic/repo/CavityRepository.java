package com.example.schematic.repo;

import com.example.schematic.domain.Cavity;
import com.example.schematic.domain.CavityId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CavityRepository extends JpaRepository<Cavity, CavityId> {
}