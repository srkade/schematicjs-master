package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "connector")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Connector {

    @Id
    @Column(name = "node_id")
    private String nodeId;        // PK (also FK to node.node_id)

    // Read-only association; resolved by node_id value. We don't write via this relation.
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "node_id", referencedColumnName = "node_id",
            insertable = false, updatable = false)
    private Node node;

    @Column(name = "engineering_code")
    private String engineeringCode;
    @Column(name = "connector_code")
    private String connectorCode;
    @Column(name = "part_number")
    private String partNumber;
    private String gender;
    @Column(name = "connector_type")
    private String connectorType;
    private String manufacturer;
}
