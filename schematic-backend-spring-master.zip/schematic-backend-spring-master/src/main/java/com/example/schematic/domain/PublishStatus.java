package com.example.schematic.domain;

public enum PublishStatus {UNPUBLISHED, PUBLISHED}
