package com.example.schematic.repo;

import com.example.schematic.domain.DtcDef;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DtcDefRepository extends JpaRepository<DtcDef, String> {
    List<DtcDef> findByConfig_ConfigId(String configId);

    Optional<DtcDef> findByConfig_ConfigIdAndCode(String configId, String code);
}
