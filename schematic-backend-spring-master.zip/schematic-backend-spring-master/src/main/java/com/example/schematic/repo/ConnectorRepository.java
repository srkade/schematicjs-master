package com.example.schematic.repo;

import com.example.schematic.domain.Connector;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConnectorRepository extends JpaRepository<Connector, String> {
}