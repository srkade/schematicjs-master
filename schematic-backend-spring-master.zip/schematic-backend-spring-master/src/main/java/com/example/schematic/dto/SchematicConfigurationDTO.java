package com.example.schematic.dto;

import com.example.schematic.domain.PublishStatus;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchematicConfigurationDTO {
    private String id;
    private String variantId;
    private String name;
    private PublishStatus status;
    private String publishedAt;
}
