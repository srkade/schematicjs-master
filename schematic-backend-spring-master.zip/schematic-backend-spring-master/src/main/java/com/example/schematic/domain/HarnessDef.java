package com.example.schematic.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "harness_def", uniqueConstraints = @UniqueConstraint(columnNames = {"config_id", "code"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HarnessDef {
    @Id
    @Column(name = "harness_id")
    private String harnessId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "config_id")
    private SchematicConfiguration config;
    @Column(nullable = false)
    private String code;
    private String name;
    private String formula; // e.g. ICC=B4=B3..
}
