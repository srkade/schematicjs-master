package com.example.schematic.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MultiSchematicDTO {
    private List<ComponentDTO> components;     // requested + connected owners
    private List<ConnectorPinsDTO> connectors; // both sides, pins = used-only
    private List<SpliceDTO> splices;           // any splices touched by these wires
    private List<WireDTO> wires;               // wires touching requested components
    private List<String> requested;            // echo of input componentIds
}
