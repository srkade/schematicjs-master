package com.example.schematic.controller;

import com.example.schematic.domain.DtcDef;
import com.example.schematic.domain.HarnessDef;
import com.example.schematic.domain.SchematicConfiguration;
import com.example.schematic.domain.SystemDef;
import com.example.schematic.dto.DtcDTO;
import com.example.schematic.dto.SystemHarnessDTO;
import com.example.schematic.repo.ComponentRepository;
import com.example.schematic.repo.DtcDefRepository;
import com.example.schematic.repo.HarnessDefRepository;
import com.example.schematic.repo.SystemDefRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/configs")
public class ConfigContentController {
    private final SystemDefRepository sysRepo;
    private final HarnessDefRepository harRepo;
    private final DtcDefRepository dtcRepo;
    private final ComponentRepository compRepo; // existing in your project

    public ConfigContentController(SystemDefRepository s, HarnessDefRepository h, DtcDefRepository d, ComponentRepository c) {
        this.sysRepo = s;
        this.harRepo = h;
        this.dtcRepo = d;
        this.compRepo = c;
    }

    // Systems
    @GetMapping("/{configId}/systems")
    public java.util.List<SystemHarnessDTO> listSystems(@PathVariable String configId) {
        return sysRepo.findByConfig_ConfigId(configId).stream()
                .map(s -> SystemHarnessDTO.builder().id(s.getSystemId()).configId(configId).code(s.getCode()).name(s.getName()).formula(s.getFormula()).build())
                .toList();
    }

    @PostMapping("/{configId}/systems")
    public ResponseEntity<?> upsertSystem(@PathVariable String configId, @RequestBody SystemHarnessDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank()) return ResponseEntity.badRequest().body("system id required");
        SystemDef s = sysRepo.findById(dto.getId()).orElseGet(() -> SystemDef.builder().systemId(dto.getId()).build());
        SchematicConfiguration cfg = new SchematicConfiguration();
        cfg.setConfigId(configId);
        s.setConfig(cfg);
        s.setCode(dto.getCode());
        s.setName(dto.getName());
        s.setFormula(dto.getFormula());
        sysRepo.save(s);
        return ResponseEntity.ok().build();
    }

    // Harnesses
    @GetMapping("/{configId}/harnesses")
    public java.util.List<SystemHarnessDTO> listHarnesses(@PathVariable String configId) {
        return harRepo.findByConfig_ConfigId(configId).stream()
                .map(h -> SystemHarnessDTO.builder().id(h.getHarnessId()).configId(configId).code(h.getCode()).name(h.getName()).formula(h.getFormula()).build())
                .toList();
    }

    @PostMapping("/{configId}/harnesses")
    public ResponseEntity<?> upsertHarness(@PathVariable String configId, @RequestBody SystemHarnessDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank())
            return ResponseEntity.badRequest().body("harness id required");
        HarnessDef h = harRepo.findById(dto.getId()).orElseGet(() -> HarnessDef.builder().harnessId(dto.getId()).build());
        SchematicConfiguration cfg = new SchematicConfiguration();
        cfg.setConfigId(configId);
        h.setConfig(cfg);
        h.setCode(dto.getCode());
        h.setName(dto.getName());
        h.setFormula(dto.getFormula());
        harRepo.save(h);
        return ResponseEntity.ok().build();
    }

    // DTCs
    @GetMapping("/{configId}/dtcs")
    public java.util.List<DtcDTO> listDtcs(@PathVariable String configId) {
        return dtcRepo.findByConfig_ConfigId(configId).stream()
                .map(d -> DtcDTO.builder().id(d.getDtcId()).configId(configId).code(d.getCode()).formula(d.getFormula()).build())
                .toList();
    }

    @PostMapping("/{configId}/dtcs")
    public ResponseEntity<?> upsertDtc(@PathVariable String configId, @RequestBody DtcDTO dto) {
        if (dto.getId() == null || dto.getId().isBlank()) return ResponseEntity.badRequest().body("dtc id required");
        DtcDef d = dtcRepo.findById(dto.getId()).orElseGet(() -> DtcDef.builder().dtcId(dto.getId()).build());
        SchematicConfiguration cfg = new SchematicConfiguration();
        cfg.setConfigId(configId);
        d.setConfig(cfg);
        d.setCode(dto.getCode());
        d.setFormula(dto.getFormula());
        dtcRepo.save(d);
        return ResponseEntity.ok().build();
    }

    // Utility: parse a formula like "ICC=B4=B3" -> ["ICC","B4","B3"]
    @GetMapping("/{configId}/parse-components")
    public java.util.List<String> parseComponents(@PathVariable String configId, @RequestParam("formula") String formula) {
        if (formula == null) return java.util.List.of();
        String[] toks = formula.trim().split("[=,; ]+");
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        for (String t : toks) {
            if (t != null && !t.isBlank()) out.add(t.trim());
        }
        return new java.util.ArrayList<>(out);
    }
}
