package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VehicleModelDTO {
    private String id;
    private String name;
    private String manufacturer;
}
