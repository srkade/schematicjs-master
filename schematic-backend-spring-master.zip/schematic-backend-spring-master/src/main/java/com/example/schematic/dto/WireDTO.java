package com.example.schematic.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WireDTO {
    private String id;
    private String circuitId;
    private WireEndDTO from;
    private WireEndDTO to;
    private String color;
}