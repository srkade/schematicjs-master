# Schematic Backend (Spring Boot)

## Quick start
1. Create a PostgreSQL DB (default `schematic`) and user.
2. Run the app:
   ```bash
   mvn spring-boot:run -Dspring-boot.run.profiles=local
   ```
   Configure DB via env:
   ```bash
   DB_URL=jdbc:postgresql://localhost:5432/schematic DB_USER=postgres DB_PASS=postgres mvn spring-boot:run
   ```

3. Load schema (will auto-run from `schema.sql` on first boot if the DB is empty).

4. Hit the API:
   ```bash
   curl http://localhost:8080/api/schematics/ECT_SENSOR
   ```

## Data model
- `component` → logical devices
- `node` → connectors & splices (unified)
- `connector` / `splice` → details
- `cavity` → pin catalog per connector
- `circuit` → nets
- `wire` → endpoints + attributes

## JSON shape
Matches the frontend:
```json
{ "components":[{"id":"ECT_SENSOR","label":"Coolant Temperature Sensor"}],
  "splices":[{"id":"XS1"}],
  "wires":[{"id":"w1","circuitId":"CIR-001","from":{"connector":"X101","cavity":"1"},"to":{"connector":"XS1","cavity":""},"color":"RED"}] }
```

## Notes
- Use your existing CSVs to import data into this schema.
- The service collects one-hop wires touching connectors that belong to the requested component.
